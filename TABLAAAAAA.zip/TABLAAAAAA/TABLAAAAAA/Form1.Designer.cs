﻿namespace TABLAAAAAA
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox12 = new PictureBox();
            pictureBox13 = new PictureBox();
            pictureBox14 = new PictureBox();
            pictureBox15 = new PictureBox();
            pictureBox16 = new PictureBox();
            pictureBox17 = new PictureBox();
            pictureBox18 = new PictureBox();
            pictureBox19 = new PictureBox();
            pictureBox20 = new PictureBox();
            pictureBox21 = new PictureBox();
            pictureBox22 = new PictureBox();
            pictureBox23 = new PictureBox();
            pictureBox24 = new PictureBox();
            pictureBox25 = new PictureBox();
            pictureBox26 = new PictureBox();
            pictureBox27 = new PictureBox();
            pictureBox28 = new PictureBox();
            pictureBox29 = new PictureBox();
            pictureBox30 = new PictureBox();
            pictureBox31 = new PictureBox();
            pictureBox32 = new PictureBox();
            pictureBox33 = new PictureBox();
            pictureBox34 = new PictureBox();
            pictureBox35 = new PictureBox();
            pictureBox36 = new PictureBox();
            pictureBox37 = new PictureBox();
            pictureBox38 = new PictureBox();
            pictureBox39 = new PictureBox();
            pictureBox40 = new PictureBox();
            pictureBox41 = new PictureBox();
            pictureBox42 = new PictureBox();
            pictureBox43 = new PictureBox();
            pictureBox44 = new PictureBox();
            pictureBox45 = new PictureBox();
            pictureBox46 = new PictureBox();
            pictureBox47 = new PictureBox();
            pictureBox48 = new PictureBox();
            pictureBox49 = new PictureBox();
            pictureBox50 = new PictureBox();
            pictureBox51 = new PictureBox();
            pictureBox52 = new PictureBox();
            pictureBox53 = new PictureBox();
            pictureBox54 = new PictureBox();
            pictureBox55 = new PictureBox();
            pictureBox56 = new PictureBox();
            pictureBox57 = new PictureBox();
            pictureBox58 = new PictureBox();
            pictureBox59 = new PictureBox();
            pictureBox60 = new PictureBox();
            pictureBox61 = new PictureBox();
            pictureBox62 = new PictureBox();
            pictureBox63 = new PictureBox();
            pictureBox64 = new PictureBox();
            azul12 = new PictureBox();
            azul11 = new PictureBox();
            azul10 = new PictureBox();
            azul9 = new PictureBox();
            azul8 = new PictureBox();
            azul7 = new PictureBox();
            azul6 = new PictureBox();
            azul5 = new PictureBox();
            azul4 = new PictureBox();
            azul3 = new PictureBox();
            azul2 = new PictureBox();
            azul1 = new PictureBox();
            roja12 = new PictureBox();
            roja11 = new PictureBox();
            roja10 = new PictureBox();
            roja9 = new PictureBox();
            roja8 = new PictureBox();
            roja7 = new PictureBox();
            roja6 = new PictureBox();
            roja5 = new PictureBox();
            roja4 = new PictureBox();
            roja3 = new PictureBox();
            roja2 = new PictureBox();
            roja1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox31).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox32).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox33).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox34).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox35).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox36).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox37).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox38).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox39).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox40).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox41).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox42).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox43).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox44).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox45).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox46).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox47).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox48).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox49).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox50).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox51).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox52).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox53).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox54).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox55).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox56).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox57).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox58).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox59).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox60).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox61).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox62).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox63).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox64).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)azul1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)roja1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Black;
            pictureBox1.Location = new Point(50, 50);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.MouseClick += cuadroClick;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.White;
            pictureBox2.Location = new Point(95, 50);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(50, 50);
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.White;
            pictureBox3.Location = new Point(188, 50);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(50, 50);
            pictureBox3.TabIndex = 3;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.Black;
            pictureBox4.Location = new Point(143, 50);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(50, 50);
            pictureBox4.TabIndex = 2;
            pictureBox4.TabStop = false;
            pictureBox4.MouseClick += cuadroClick;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.White;
            pictureBox5.Location = new Point(374, 50);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(50, 50);
            pictureBox5.TabIndex = 7;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.Black;
            pictureBox6.Location = new Point(329, 50);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(50, 50);
            pictureBox6.TabIndex = 6;
            pictureBox6.TabStop = false;
            pictureBox6.MouseClick += cuadroClick;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.White;
            pictureBox7.Location = new Point(281, 50);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(50, 50);
            pictureBox7.TabIndex = 5;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.Black;
            pictureBox8.Location = new Point(236, 50);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(50, 50);
            pictureBox8.TabIndex = 4;
            pictureBox8.TabStop = false;
            pictureBox8.MouseClick += cuadroClick;
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.Black;
            pictureBox9.Location = new Point(374, 95);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(50, 50);
            pictureBox9.TabIndex = 15;
            pictureBox9.TabStop = false;
            pictureBox9.MouseClick += cuadroClick;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.White;
            pictureBox10.Location = new Point(329, 95);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(50, 50);
            pictureBox10.TabIndex = 14;
            pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.Black;
            pictureBox11.Location = new Point(281, 95);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(50, 50);
            pictureBox11.TabIndex = 13;
            pictureBox11.TabStop = false;
            pictureBox11.MouseClick += cuadroClick;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = Color.White;
            pictureBox12.Location = new Point(236, 95);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(50, 50);
            pictureBox12.TabIndex = 12;
            pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            pictureBox13.BackColor = Color.Black;
            pictureBox13.Location = new Point(188, 95);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(50, 50);
            pictureBox13.TabIndex = 11;
            pictureBox13.TabStop = false;
            pictureBox13.MouseClick += cuadroClick;
            // 
            // pictureBox14
            // 
            pictureBox14.BackColor = Color.White;
            pictureBox14.Location = new Point(143, 95);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(50, 50);
            pictureBox14.TabIndex = 10;
            pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            pictureBox15.BackColor = Color.Black;
            pictureBox15.Location = new Point(95, 95);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(50, 50);
            pictureBox15.TabIndex = 9;
            pictureBox15.TabStop = false;
            pictureBox15.MouseClick += cuadroClick;
            // 
            // pictureBox16
            // 
            pictureBox16.BackColor = Color.White;
            pictureBox16.Location = new Point(50, 95);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(50, 50);
            pictureBox16.TabIndex = 8;
            pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            pictureBox17.BackColor = Color.Black;
            pictureBox17.Location = new Point(374, 185);
            pictureBox17.Name = "pictureBox17";
            pictureBox17.Size = new Size(50, 50);
            pictureBox17.TabIndex = 31;
            pictureBox17.TabStop = false;
            pictureBox17.MouseClick += cuadroClick;
            // 
            // pictureBox18
            // 
            pictureBox18.BackColor = Color.White;
            pictureBox18.Location = new Point(329, 185);
            pictureBox18.Name = "pictureBox18";
            pictureBox18.Size = new Size(50, 50);
            pictureBox18.TabIndex = 30;
            pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            pictureBox19.BackColor = Color.Black;
            pictureBox19.Location = new Point(281, 185);
            pictureBox19.Name = "pictureBox19";
            pictureBox19.Size = new Size(50, 50);
            pictureBox19.TabIndex = 29;
            pictureBox19.TabStop = false;
            pictureBox19.MouseClick += cuadroClick;
            // 
            // pictureBox20
            // 
            pictureBox20.BackColor = Color.White;
            pictureBox20.Location = new Point(236, 185);
            pictureBox20.Name = "pictureBox20";
            pictureBox20.Size = new Size(50, 50);
            pictureBox20.TabIndex = 28;
            pictureBox20.TabStop = false;
            // 
            // pictureBox21
            // 
            pictureBox21.BackColor = Color.Black;
            pictureBox21.Location = new Point(188, 185);
            pictureBox21.Name = "pictureBox21";
            pictureBox21.Size = new Size(50, 50);
            pictureBox21.TabIndex = 27;
            pictureBox21.TabStop = false;
            pictureBox21.MouseClick += cuadroClick;
            // 
            // pictureBox22
            // 
            pictureBox22.BackColor = Color.White;
            pictureBox22.Location = new Point(143, 185);
            pictureBox22.Name = "pictureBox22";
            pictureBox22.Size = new Size(50, 50);
            pictureBox22.TabIndex = 26;
            pictureBox22.TabStop = false;
            // 
            // pictureBox23
            // 
            pictureBox23.BackColor = Color.Black;
            pictureBox23.Location = new Point(95, 185);
            pictureBox23.Name = "pictureBox23";
            pictureBox23.Size = new Size(50, 50);
            pictureBox23.TabIndex = 25;
            pictureBox23.TabStop = false;
            pictureBox23.MouseClick += cuadroClick;
            // 
            // pictureBox24
            // 
            pictureBox24.BackColor = Color.White;
            pictureBox24.Location = new Point(50, 185);
            pictureBox24.Name = "pictureBox24";
            pictureBox24.Size = new Size(50, 50);
            pictureBox24.TabIndex = 24;
            pictureBox24.TabStop = false;
            // 
            // pictureBox25
            // 
            pictureBox25.BackColor = Color.White;
            pictureBox25.Location = new Point(374, 140);
            pictureBox25.Name = "pictureBox25";
            pictureBox25.Size = new Size(50, 50);
            pictureBox25.TabIndex = 23;
            pictureBox25.TabStop = false;
            // 
            // pictureBox26
            // 
            pictureBox26.BackColor = Color.Black;
            pictureBox26.Location = new Point(329, 140);
            pictureBox26.Name = "pictureBox26";
            pictureBox26.Size = new Size(50, 50);
            pictureBox26.TabIndex = 22;
            pictureBox26.TabStop = false;
            pictureBox26.MouseClick += cuadroClick;
            // 
            // pictureBox27
            // 
            pictureBox27.BackColor = Color.White;
            pictureBox27.Location = new Point(281, 140);
            pictureBox27.Name = "pictureBox27";
            pictureBox27.Size = new Size(50, 50);
            pictureBox27.TabIndex = 21;
            pictureBox27.TabStop = false;
            // 
            // pictureBox28
            // 
            pictureBox28.BackColor = Color.Black;
            pictureBox28.Location = new Point(236, 140);
            pictureBox28.Name = "pictureBox28";
            pictureBox28.Size = new Size(50, 50);
            pictureBox28.TabIndex = 20;
            pictureBox28.TabStop = false;
            pictureBox28.MouseClick += cuadroClick;
            // 
            // pictureBox29
            // 
            pictureBox29.BackColor = Color.White;
            pictureBox29.Location = new Point(188, 140);
            pictureBox29.Name = "pictureBox29";
            pictureBox29.Size = new Size(50, 50);
            pictureBox29.TabIndex = 19;
            pictureBox29.TabStop = false;
            // 
            // pictureBox30
            // 
            pictureBox30.BackColor = Color.Black;
            pictureBox30.Location = new Point(143, 140);
            pictureBox30.Name = "pictureBox30";
            pictureBox30.Size = new Size(50, 50);
            pictureBox30.TabIndex = 18;
            pictureBox30.TabStop = false;
            pictureBox30.MouseClick += cuadroClick;
            // 
            // pictureBox31
            // 
            pictureBox31.BackColor = Color.White;
            pictureBox31.Location = new Point(95, 140);
            pictureBox31.Name = "pictureBox31";
            pictureBox31.Size = new Size(50, 50);
            pictureBox31.TabIndex = 17;
            pictureBox31.TabStop = false;
            // 
            // pictureBox32
            // 
            pictureBox32.BackColor = Color.Black;
            pictureBox32.Location = new Point(50, 140);
            pictureBox32.Name = "pictureBox32";
            pictureBox32.Size = new Size(50, 50);
            pictureBox32.TabIndex = 16;
            pictureBox32.TabStop = false;
            pictureBox32.MouseClick += cuadroClick;
            // 
            // pictureBox33
            // 
            pictureBox33.BackColor = Color.Black;
            pictureBox33.Location = new Point(374, 369);
            pictureBox33.Name = "pictureBox33";
            pictureBox33.Size = new Size(50, 50);
            pictureBox33.TabIndex = 63;
            pictureBox33.TabStop = false;
            pictureBox33.MouseClick += cuadroClick;
            // 
            // pictureBox34
            // 
            pictureBox34.BackColor = Color.White;
            pictureBox34.Location = new Point(329, 369);
            pictureBox34.Name = "pictureBox34";
            pictureBox34.Size = new Size(50, 50);
            pictureBox34.TabIndex = 62;
            pictureBox34.TabStop = false;
            // 
            // pictureBox35
            // 
            pictureBox35.BackColor = Color.Black;
            pictureBox35.Location = new Point(281, 369);
            pictureBox35.Name = "pictureBox35";
            pictureBox35.Size = new Size(50, 50);
            pictureBox35.TabIndex = 61;
            pictureBox35.TabStop = false;
            pictureBox35.MouseClick += cuadroClick;
            // 
            // pictureBox36
            // 
            pictureBox36.BackColor = Color.White;
            pictureBox36.Location = new Point(236, 369);
            pictureBox36.Name = "pictureBox36";
            pictureBox36.Size = new Size(50, 50);
            pictureBox36.TabIndex = 60;
            pictureBox36.TabStop = false;
            // 
            // pictureBox37
            // 
            pictureBox37.BackColor = Color.Black;
            pictureBox37.Location = new Point(188, 369);
            pictureBox37.Name = "pictureBox37";
            pictureBox37.Size = new Size(50, 50);
            pictureBox37.TabIndex = 59;
            pictureBox37.TabStop = false;
            pictureBox37.MouseClick += cuadroClick;
            // 
            // pictureBox38
            // 
            pictureBox38.BackColor = Color.White;
            pictureBox38.Location = new Point(143, 369);
            pictureBox38.Name = "pictureBox38";
            pictureBox38.Size = new Size(50, 50);
            pictureBox38.TabIndex = 58;
            pictureBox38.TabStop = false;
            // 
            // pictureBox39
            // 
            pictureBox39.BackColor = Color.Black;
            pictureBox39.Location = new Point(95, 369);
            pictureBox39.Name = "pictureBox39";
            pictureBox39.Size = new Size(50, 50);
            pictureBox39.TabIndex = 57;
            pictureBox39.TabStop = false;
            pictureBox39.MouseClick += cuadroClick;
            // 
            // pictureBox40
            // 
            pictureBox40.BackColor = Color.White;
            pictureBox40.Location = new Point(50, 369);
            pictureBox40.Name = "pictureBox40";
            pictureBox40.Size = new Size(50, 50);
            pictureBox40.TabIndex = 56;
            pictureBox40.TabStop = false;
            // 
            // pictureBox41
            // 
            pictureBox41.BackColor = Color.White;
            pictureBox41.Location = new Point(374, 324);
            pictureBox41.Name = "pictureBox41";
            pictureBox41.Size = new Size(50, 50);
            pictureBox41.TabIndex = 55;
            pictureBox41.TabStop = false;
            // 
            // pictureBox42
            // 
            pictureBox42.BackColor = Color.Black;
            pictureBox42.Location = new Point(329, 324);
            pictureBox42.Name = "pictureBox42";
            pictureBox42.Size = new Size(50, 50);
            pictureBox42.TabIndex = 54;
            pictureBox42.TabStop = false;
            pictureBox42.MouseClick += cuadroClick;
            // 
            // pictureBox43
            // 
            pictureBox43.BackColor = Color.White;
            pictureBox43.Location = new Point(281, 324);
            pictureBox43.Name = "pictureBox43";
            pictureBox43.Size = new Size(50, 50);
            pictureBox43.TabIndex = 53;
            pictureBox43.TabStop = false;
            // 
            // pictureBox44
            // 
            pictureBox44.BackColor = Color.Black;
            pictureBox44.Location = new Point(236, 324);
            pictureBox44.Name = "pictureBox44";
            pictureBox44.Size = new Size(50, 50);
            pictureBox44.TabIndex = 52;
            pictureBox44.TabStop = false;
            pictureBox44.MouseClick += cuadroClick;
            // 
            // pictureBox45
            // 
            pictureBox45.BackColor = Color.White;
            pictureBox45.Location = new Point(188, 324);
            pictureBox45.Name = "pictureBox45";
            pictureBox45.Size = new Size(50, 50);
            pictureBox45.TabIndex = 51;
            pictureBox45.TabStop = false;
            // 
            // pictureBox46
            // 
            pictureBox46.BackColor = Color.Black;
            pictureBox46.Location = new Point(143, 324);
            pictureBox46.Name = "pictureBox46";
            pictureBox46.Size = new Size(50, 50);
            pictureBox46.TabIndex = 50;
            pictureBox46.TabStop = false;
            pictureBox46.MouseClick += cuadroClick;
            // 
            // pictureBox47
            // 
            pictureBox47.BackColor = Color.White;
            pictureBox47.Location = new Point(95, 324);
            pictureBox47.Name = "pictureBox47";
            pictureBox47.Size = new Size(50, 50);
            pictureBox47.TabIndex = 49;
            pictureBox47.TabStop = false;
            // 
            // pictureBox48
            // 
            pictureBox48.BackColor = Color.Black;
            pictureBox48.Location = new Point(50, 324);
            pictureBox48.Name = "pictureBox48";
            pictureBox48.Size = new Size(50, 50);
            pictureBox48.TabIndex = 48;
            pictureBox48.TabStop = false;
            pictureBox48.MouseClick += cuadroClick;
            // 
            // pictureBox49
            // 
            pictureBox49.BackColor = Color.Black;
            pictureBox49.Location = new Point(374, 279);
            pictureBox49.Name = "pictureBox49";
            pictureBox49.Size = new Size(50, 50);
            pictureBox49.TabIndex = 47;
            pictureBox49.TabStop = false;
            pictureBox49.MouseClick += cuadroClick;
            // 
            // pictureBox50
            // 
            pictureBox50.BackColor = Color.White;
            pictureBox50.Location = new Point(329, 279);
            pictureBox50.Name = "pictureBox50";
            pictureBox50.Size = new Size(50, 50);
            pictureBox50.TabIndex = 46;
            pictureBox50.TabStop = false;
            // 
            // pictureBox51
            // 
            pictureBox51.BackColor = Color.Black;
            pictureBox51.Location = new Point(281, 279);
            pictureBox51.Name = "pictureBox51";
            pictureBox51.Size = new Size(50, 50);
            pictureBox51.TabIndex = 45;
            pictureBox51.TabStop = false;
            pictureBox51.MouseClick += cuadroClick;
            // 
            // pictureBox52
            // 
            pictureBox52.BackColor = Color.White;
            pictureBox52.Location = new Point(236, 279);
            pictureBox52.Name = "pictureBox52";
            pictureBox52.Size = new Size(50, 50);
            pictureBox52.TabIndex = 44;
            pictureBox52.TabStop = false;
            // 
            // pictureBox53
            // 
            pictureBox53.BackColor = Color.Black;
            pictureBox53.Location = new Point(188, 279);
            pictureBox53.Name = "pictureBox53";
            pictureBox53.Size = new Size(50, 50);
            pictureBox53.TabIndex = 43;
            pictureBox53.TabStop = false;
            pictureBox53.MouseClick += cuadroClick;
            // 
            // pictureBox54
            // 
            pictureBox54.BackColor = Color.White;
            pictureBox54.Location = new Point(143, 279);
            pictureBox54.Name = "pictureBox54";
            pictureBox54.Size = new Size(50, 50);
            pictureBox54.TabIndex = 42;
            pictureBox54.TabStop = false;
            // 
            // pictureBox55
            // 
            pictureBox55.BackColor = Color.Black;
            pictureBox55.Location = new Point(95, 279);
            pictureBox55.Name = "pictureBox55";
            pictureBox55.Size = new Size(50, 50);
            pictureBox55.TabIndex = 41;
            pictureBox55.TabStop = false;
            pictureBox55.MouseClick += cuadroClick;
            // 
            // pictureBox56
            // 
            pictureBox56.BackColor = Color.White;
            pictureBox56.Location = new Point(50, 279);
            pictureBox56.Name = "pictureBox56";
            pictureBox56.Size = new Size(50, 50);
            pictureBox56.TabIndex = 40;
            pictureBox56.TabStop = false;
            // 
            // pictureBox57
            // 
            pictureBox57.BackColor = Color.White;
            pictureBox57.Location = new Point(374, 234);
            pictureBox57.Name = "pictureBox57";
            pictureBox57.Size = new Size(50, 50);
            pictureBox57.TabIndex = 39;
            pictureBox57.TabStop = false;
            // 
            // pictureBox58
            // 
            pictureBox58.BackColor = Color.Black;
            pictureBox58.Location = new Point(329, 234);
            pictureBox58.Name = "pictureBox58";
            pictureBox58.Size = new Size(50, 50);
            pictureBox58.TabIndex = 38;
            pictureBox58.TabStop = false;
            pictureBox58.MouseClick += cuadroClick;
            // 
            // pictureBox59
            // 
            pictureBox59.BackColor = Color.White;
            pictureBox59.Location = new Point(281, 234);
            pictureBox59.Name = "pictureBox59";
            pictureBox59.Size = new Size(50, 50);
            pictureBox59.TabIndex = 37;
            pictureBox59.TabStop = false;
            // 
            // pictureBox60
            // 
            pictureBox60.BackColor = Color.Black;
            pictureBox60.Location = new Point(236, 234);
            pictureBox60.Name = "pictureBox60";
            pictureBox60.Size = new Size(50, 50);
            pictureBox60.TabIndex = 36;
            pictureBox60.TabStop = false;
            pictureBox60.MouseClick += cuadroClick;
            // 
            // pictureBox61
            // 
            pictureBox61.BackColor = Color.White;
            pictureBox61.Location = new Point(188, 234);
            pictureBox61.Name = "pictureBox61";
            pictureBox61.Size = new Size(50, 50);
            pictureBox61.TabIndex = 35;
            pictureBox61.TabStop = false;
            // 
            // pictureBox62
            // 
            pictureBox62.BackColor = Color.Black;
            pictureBox62.Location = new Point(143, 234);
            pictureBox62.Name = "pictureBox62";
            pictureBox62.Size = new Size(50, 50);
            pictureBox62.TabIndex = 34;
            pictureBox62.TabStop = false;
            pictureBox62.MouseClick += cuadroClick;
            // 
            // pictureBox63
            // 
            pictureBox63.BackColor = Color.White;
            pictureBox63.Location = new Point(95, 234);
            pictureBox63.Name = "pictureBox63";
            pictureBox63.Size = new Size(50, 50);
            pictureBox63.TabIndex = 33;
            pictureBox63.TabStop = false;
            // 
            // pictureBox64
            // 
            pictureBox64.BackColor = Color.Black;
            pictureBox64.Location = new Point(50, 234);
            pictureBox64.Name = "pictureBox64";
            pictureBox64.Size = new Size(50, 50);
            pictureBox64.TabIndex = 32;
            pictureBox64.TabStop = false;
            pictureBox64.MouseClick += cuadroClick;
            // 
            // azul12
            // 
            azul12.BackColor = Color.Black;
            azul12.BackgroundImage = (Image)resources.GetObject("azul12.BackgroundImage");
            azul12.Location = new Point(329, 140);
            azul12.Name = "azul12";
            azul12.Size = new Size(53, 50);
            azul12.TabIndex = 86;
            azul12.TabStop = false;
            azul12.MouseClick += seleccionAzul;
            // 
            // azul11
            // 
            azul11.BackColor = Color.Black;
            azul11.BackgroundImage = (Image)resources.GetObject("azul11.BackgroundImage");
            azul11.Location = new Point(236, 140);
            azul11.Name = "azul11";
            azul11.Size = new Size(53, 50);
            azul11.TabIndex = 84;
            azul11.TabStop = false;
            azul11.MouseClick += seleccionAzul;
            // 
            // azul10
            // 
            azul10.BackColor = Color.Black;
            azul10.BackgroundImage = (Image)resources.GetObject("azul10.BackgroundImage");
            azul10.Location = new Point(143, 140);
            azul10.Name = "azul10";
            azul10.Size = new Size(53, 50);
            azul10.TabIndex = 82;
            azul10.TabStop = false;
            azul10.MouseClick += seleccionAzul;
            // 
            // azul9
            // 
            azul9.BackColor = Color.Black;
            azul9.BackgroundImage = (Image)resources.GetObject("azul9.BackgroundImage");
            azul9.Location = new Point(50, 140);
            azul9.Name = "azul9";
            azul9.Size = new Size(53, 50);
            azul9.TabIndex = 80;
            azul9.TabStop = false;
            azul9.MouseClick += seleccionAzul;
            // 
            // azul8
            // 
            azul8.BackColor = Color.Black;
            azul8.BackgroundImage = (Image)resources.GetObject("azul8.BackgroundImage");
            azul8.Location = new Point(374, 95);
            azul8.Name = "azul8";
            azul8.Size = new Size(53, 50);
            azul8.TabIndex = 79;
            azul8.TabStop = false;
            azul8.MouseClick += seleccionAzul;
            // 
            // azul7
            // 
            azul7.BackColor = Color.Black;
            azul7.BackgroundImage = (Image)resources.GetObject("azul7.BackgroundImage");
            azul7.Location = new Point(281, 95);
            azul7.Name = "azul7";
            azul7.Size = new Size(53, 50);
            azul7.TabIndex = 77;
            azul7.TabStop = false;
            azul7.MouseClick += seleccionAzul;
            // 
            // azul6
            // 
            azul6.BackColor = Color.Black;
            azul6.BackgroundImage = (Image)resources.GetObject("azul6.BackgroundImage");
            azul6.Location = new Point(188, 95);
            azul6.Name = "azul6";
            azul6.Size = new Size(53, 50);
            azul6.TabIndex = 75;
            azul6.TabStop = false;
            azul6.MouseClick += seleccionAzul;
            // 
            // azul5
            // 
            azul5.BackColor = Color.Black;
            azul5.BackgroundImage = (Image)resources.GetObject("azul5.BackgroundImage");
            azul5.Location = new Point(95, 95);
            azul5.Name = "azul5";
            azul5.Size = new Size(53, 50);
            azul5.TabIndex = 73;
            azul5.TabStop = false;
            azul5.MouseClick += seleccionAzul;
            // 
            // azul4
            // 
            azul4.BackColor = Color.Black;
            azul4.BackgroundImage = (Image)resources.GetObject("azul4.BackgroundImage");
            azul4.Location = new Point(329, 50);
            azul4.Name = "azul4";
            azul4.Size = new Size(53, 50);
            azul4.TabIndex = 70;
            azul4.TabStop = false;
            azul4.MouseClick += seleccionAzul;
            // 
            // azul3
            // 
            azul3.BackColor = Color.Black;
            azul3.BackgroundImage = (Image)resources.GetObject("azul3.BackgroundImage");
            azul3.Location = new Point(236, 50);
            azul3.Name = "azul3";
            azul3.Size = new Size(53, 50);
            azul3.TabIndex = 68;
            azul3.TabStop = false;
            azul3.MouseClick += seleccionAzul;
            // 
            // azul2
            // 
            azul2.BackColor = Color.Black;
            azul2.BackgroundImage = (Image)resources.GetObject("azul2.BackgroundImage");
            azul2.Location = new Point(143, 50);
            azul2.Name = "azul2";
            azul2.Size = new Size(53, 50);
            azul2.TabIndex = 66;
            azul2.TabStop = false;
            azul2.MouseClick += seleccionAzul;
            // 
            // azul1
            // 
            azul1.BackColor = Color.Black;
            azul1.BackgroundImage = (Image)resources.GetObject("azul1.BackgroundImage");
            azul1.Location = new Point(50, 50);
            azul1.Name = "azul1";
            azul1.Size = new Size(53, 50);
            azul1.TabIndex = 64;
            azul1.TabStop = false;
            azul1.MouseClick += seleccionAzul;
            // 
            // roja12
            // 
            roja12.BackColor = Color.Black;
            roja12.BackgroundImage = (Image)resources.GetObject("roja12.BackgroundImage");
            roja12.Location = new Point(367, 369);
            roja12.Name = "roja12";
            roja12.Size = new Size(53, 50);
            roja12.TabIndex = 99;
            roja12.TabStop = false;
            roja12.MouseClick += seleccionRoja;
            // 
            // roja11
            // 
            roja11.BackColor = Color.Black;
            roja11.BackgroundImage = (Image)resources.GetObject("roja11.BackgroundImage");
            roja11.Location = new Point(274, 369);
            roja11.Name = "roja11";
            roja11.Size = new Size(53, 50);
            roja11.TabIndex = 98;
            roja11.TabStop = false;
            roja11.MouseClick += seleccionRoja;
            // 
            // roja10
            // 
            roja10.BackColor = Color.Black;
            roja10.BackgroundImage = (Image)resources.GetObject("roja10.BackgroundImage");
            roja10.Location = new Point(181, 369);
            roja10.Name = "roja10";
            roja10.Size = new Size(53, 50);
            roja10.TabIndex = 96;
            roja10.TabStop = false;
            roja10.MouseClick += seleccionRoja;
            // 
            // roja9
            // 
            roja9.BackColor = Color.Black;
            roja9.BackgroundImage = (Image)resources.GetObject("roja9.BackgroundImage");
            roja9.Location = new Point(88, 369);
            roja9.Name = "roja9";
            roja9.Size = new Size(53, 50);
            roja9.TabIndex = 95;
            roja9.TabStop = false;
            roja9.MouseClick += seleccionRoja;
            // 
            // roja8
            // 
            roja8.BackColor = Color.Black;
            roja8.BackgroundImage = (Image)resources.GetObject("roja8.BackgroundImage");
            roja8.Location = new Point(47, 324);
            roja8.Name = "roja8";
            roja8.Size = new Size(53, 50);
            roja8.TabIndex = 94;
            roja8.TabStop = false;
            roja8.MouseClick += seleccionRoja;
            // 
            // roja7
            // 
            roja7.BackColor = Color.Black;
            roja7.BackgroundImage = (Image)resources.GetObject("roja7.BackgroundImage");
            roja7.Location = new Point(319, 324);
            roja7.Name = "roja7";
            roja7.Size = new Size(53, 50);
            roja7.TabIndex = 93;
            roja7.TabStop = false;
            roja7.MouseClick += seleccionRoja;
            // 
            // roja6
            // 
            roja6.BackColor = Color.Black;
            roja6.BackgroundImage = (Image)resources.GetObject("roja6.BackgroundImage");
            roja6.Location = new Point(230, 324);
            roja6.Name = "roja6";
            roja6.Size = new Size(53, 50);
            roja6.TabIndex = 92;
            roja6.TabStop = false;
            roja6.MouseClick += seleccionRoja;
            // 
            // roja5
            // 
            roja5.BackColor = Color.Black;
            roja5.BackgroundImage = (Image)resources.GetObject("roja5.BackgroundImage");
            roja5.Location = new Point(133, 324);
            roja5.Name = "roja5";
            roja5.Size = new Size(53, 50);
            roja5.TabIndex = 91;
            roja5.TabStop = false;
            roja5.MouseClick += seleccionRoja;
            // 
            // roja4
            // 
            roja4.BackColor = Color.Black;
            roja4.BackgroundImage = (Image)resources.GetObject("roja4.BackgroundImage");
            roja4.Location = new Point(367, 279);
            roja4.Name = "roja4";
            roja4.Size = new Size(53, 50);
            roja4.TabIndex = 90;
            roja4.TabStop = false;
            roja4.MouseClick += seleccionRoja;
            // 
            // roja3
            // 
            roja3.BackColor = Color.Black;
            roja3.BackgroundImage = (Image)resources.GetObject("roja3.BackgroundImage");
            roja3.Location = new Point(274, 279);
            roja3.Name = "roja3";
            roja3.Size = new Size(53, 50);
            roja3.TabIndex = 89;
            roja3.TabStop = false;
            roja3.MouseClick += seleccionRoja;
            // 
            // roja2
            // 
            roja2.BackColor = Color.Black;
            roja2.BackgroundImage = (Image)resources.GetObject("roja2.BackgroundImage");
            roja2.Location = new Point(181, 279);
            roja2.Name = "roja2";
            roja2.Size = new Size(53, 50);
            roja2.TabIndex = 88;
            roja2.TabStop = false;
            roja2.MouseClick += seleccionRoja;
            // 
            // roja1
            // 
            roja1.BackColor = Color.Black;
            roja1.BackgroundImage = (Image)resources.GetObject("roja1.BackgroundImage");
            roja1.Location = new Point(88, 279);
            roja1.Name = "roja1";
            roja1.Size = new Size(53, 50);
            roja1.TabIndex = 87;
            roja1.TabStop = false;
            roja1.MouseClick += seleccionRoja;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(800, 450);
            Controls.Add(roja12);
            Controls.Add(roja11);
            Controls.Add(roja10);
            Controls.Add(roja9);
            Controls.Add(roja8);
            Controls.Add(roja7);
            Controls.Add(roja6);
            Controls.Add(roja5);
            Controls.Add(roja4);
            Controls.Add(roja3);
            Controls.Add(roja2);
            Controls.Add(roja1);
            Controls.Add(azul12);
            Controls.Add(azul11);
            Controls.Add(azul10);
            Controls.Add(azul9);
            Controls.Add(azul8);
            Controls.Add(azul7);
            Controls.Add(azul6);
            Controls.Add(azul5);
            Controls.Add(azul4);
            Controls.Add(azul3);
            Controls.Add(azul2);
            Controls.Add(azul1);
            Controls.Add(pictureBox33);
            Controls.Add(pictureBox34);
            Controls.Add(pictureBox35);
            Controls.Add(pictureBox36);
            Controls.Add(pictureBox37);
            Controls.Add(pictureBox38);
            Controls.Add(pictureBox39);
            Controls.Add(pictureBox40);
            Controls.Add(pictureBox41);
            Controls.Add(pictureBox42);
            Controls.Add(pictureBox43);
            Controls.Add(pictureBox44);
            Controls.Add(pictureBox45);
            Controls.Add(pictureBox46);
            Controls.Add(pictureBox47);
            Controls.Add(pictureBox48);
            Controls.Add(pictureBox49);
            Controls.Add(pictureBox50);
            Controls.Add(pictureBox51);
            Controls.Add(pictureBox52);
            Controls.Add(pictureBox53);
            Controls.Add(pictureBox54);
            Controls.Add(pictureBox55);
            Controls.Add(pictureBox56);
            Controls.Add(pictureBox57);
            Controls.Add(pictureBox58);
            Controls.Add(pictureBox59);
            Controls.Add(pictureBox60);
            Controls.Add(pictureBox61);
            Controls.Add(pictureBox62);
            Controls.Add(pictureBox63);
            Controls.Add(pictureBox64);
            Controls.Add(pictureBox17);
            Controls.Add(pictureBox18);
            Controls.Add(pictureBox19);
            Controls.Add(pictureBox20);
            Controls.Add(pictureBox21);
            Controls.Add(pictureBox22);
            Controls.Add(pictureBox23);
            Controls.Add(pictureBox24);
            Controls.Add(pictureBox25);
            Controls.Add(pictureBox26);
            Controls.Add(pictureBox27);
            Controls.Add(pictureBox28);
            Controls.Add(pictureBox29);
            Controls.Add(pictureBox30);
            Controls.Add(pictureBox31);
            Controls.Add(pictureBox32);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox14);
            Controls.Add(pictureBox15);
            Controls.Add(pictureBox16);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Name = "Form1";
            Text = "Form1";
  
            MouseClick += cuadroClick;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox31).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox32).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox33).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox34).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox35).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox36).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox37).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox38).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox39).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox40).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox41).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox42).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox43).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox44).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox45).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox46).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox47).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox48).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox49).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox50).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox51).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox52).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox53).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox54).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox55).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox56).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox57).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox58).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox59).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox60).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox61).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox62).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox63).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox64).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul12).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul11).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul10).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul9).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul8).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul7).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul6).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul5).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul4).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul3).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul2).EndInit();
            ((System.ComponentModel.ISupportInitialize)azul1).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja12).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja11).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja10).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja9).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja8).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja7).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja6).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja5).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja4).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja3).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja2).EndInit();
            ((System.ComponentModel.ISupportInitialize)roja1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
        private PictureBox pictureBox14;
        private PictureBox pictureBox15;
        private PictureBox pictureBox16;
        private PictureBox pictureBox17;
        private PictureBox pictureBox18;
        private PictureBox pictureBox19;
        private PictureBox pictureBox20;
        private PictureBox pictureBox21;
        private PictureBox pictureBox22;
        private PictureBox pictureBox23;
        private PictureBox pictureBox24;
        private PictureBox pictureBox25;
        private PictureBox pictureBox26;
        private PictureBox pictureBox27;
        private PictureBox pictureBox28;
        private PictureBox pictureBox29;
        private PictureBox pictureBox30;
        private PictureBox pictureBox31;
        private PictureBox pictureBox32;
        private PictureBox pictureBox33;
        private PictureBox pictureBox34;
        private PictureBox pictureBox35;
        private PictureBox pictureBox36;
        private PictureBox pictureBox37;
        private PictureBox pictureBox38;
        private PictureBox pictureBox39;
        private PictureBox pictureBox40;
        private PictureBox pictureBox41;
        private PictureBox pictureBox42;
        private PictureBox pictureBox43;
        private PictureBox pictureBox44;
        private PictureBox pictureBox45;
        private PictureBox pictureBox46;
        private PictureBox pictureBox47;
        private PictureBox pictureBox48;
        private PictureBox pictureBox49;
        private PictureBox pictureBox50;
        private PictureBox pictureBox51;
        private PictureBox pictureBox52;
        private PictureBox pictureBox53;
        private PictureBox pictureBox54;
        private PictureBox pictureBox55;
        private PictureBox pictureBox56;
        private PictureBox pictureBox57;
        private PictureBox pictureBox58;
        private PictureBox pictureBox59;
        private PictureBox pictureBox60;
        private PictureBox pictureBox61;
        private PictureBox pictureBox62;
        private PictureBox pictureBox63;
        private PictureBox pictureBox64;
        private PictureBox azul12;
        private PictureBox azul11;
        private PictureBox azul10;
        private PictureBox azul9;
        private PictureBox azul8;
        private PictureBox azul7;
        private PictureBox azul6;
        private PictureBox azul5;
        private PictureBox azul4;
        private PictureBox azul3;
        private PictureBox azul2;
        private PictureBox azul1;
        private PictureBox roja12;
        private PictureBox roja11;
        private PictureBox roja10;
        private PictureBox roja9;
        private PictureBox roja8;
        private PictureBox roja7;
        private PictureBox roja6;
        private PictureBox roja5;
        private PictureBox roja4;
        private PictureBox roja3;
        private PictureBox roja2;
        private PictureBox roja1;
    }
}
